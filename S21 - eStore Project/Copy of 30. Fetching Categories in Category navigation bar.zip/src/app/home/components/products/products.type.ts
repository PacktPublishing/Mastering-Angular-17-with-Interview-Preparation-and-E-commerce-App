export interface ProductListItem {
    id: number;
    product_name: string;
    product_img: string;
    price: number;
    ratings: number;
}