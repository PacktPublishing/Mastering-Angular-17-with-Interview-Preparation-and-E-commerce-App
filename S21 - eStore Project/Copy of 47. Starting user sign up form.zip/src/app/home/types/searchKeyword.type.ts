export interface SearchKeyword {
  categoryId: number;
  keyword: string;
}
