export class UserServiceMock {
  isUserAuthenticated: any;
  isUserAuthenticated$: any;
  loggedInUser$: any;
  loggedInUser: any;
  token: any;
  createUser(): any {}
  login(): any {}
  activateToken(): any {}
  logout(): any {}
  loadToken(): any {}
}
