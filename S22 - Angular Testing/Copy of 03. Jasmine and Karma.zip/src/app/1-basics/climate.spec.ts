import { getClimate } from './climate';

fdescribe('getClimate', () => {
  it('should return Freezing Cold text for temperature less than 41 degree', () => {
    const result: string = getClimate(31);
    expect(result).toEqual('Freezing Cold');
  });

  it('should return Moderate text for temprature between 65 and 81', () => {
    const result: string = getClimate(70);
    expect(result).toEqual('Moderate');
  });
});
