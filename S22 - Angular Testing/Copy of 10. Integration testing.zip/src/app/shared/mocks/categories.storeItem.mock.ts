import { Observable, of } from 'rxjs';
import { Category } from 'src/app/home/types/category.type';

export class CategoriesStoreItemMock {
  loadCategories(): any {}
  categories$: any;
  topLevelCategories$: Observable<Category[]> = of([
    {
      id: 1,
      category: 'Category 1',
    },
    {
      id: 2,
      category: 'Category 2',
    },
  ]);
}
