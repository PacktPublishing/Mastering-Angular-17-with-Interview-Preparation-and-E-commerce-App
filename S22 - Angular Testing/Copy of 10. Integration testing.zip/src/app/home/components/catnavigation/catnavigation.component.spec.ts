import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CatnavigationComponent } from './catnavigation.component';
import { CategoriesStoreItem } from '../../services/category/categories.storeItem';
import { CategoriesStoreItemMock } from 'src/app/shared/mocks/categories.storeItem.mock';
import { By } from '@angular/platform-browser';
import { RouterTestingModule } from '@angular/router/testing';

fdescribe('CatnavigationComponent', () => {
  let component: CatnavigationComponent;
  let fixture: ComponentFixture<CatnavigationComponent>;
  let categoriesStoreItem: CategoriesStoreItem;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CatnavigationComponent],
      providers: [
        { provide: CategoriesStoreItem, useClass: CategoriesStoreItemMock },
      ],
      imports: [RouterTestingModule],
    }).compileComponents();

    fixture = TestBed.createComponent(CatnavigationComponent);
    component = fixture.componentInstance;
    categoriesStoreItem = TestBed.inject(CategoriesStoreItem);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display only category, Home, if displayOptions is false', () => {
    component.displayOptions = false;
    fixture.detectChanges();
    expect(fixture.debugElement.queryAll(By.css('li')).length).toEqual(1);
    expect(fixture.debugElement.queryAll(By.css('a')).length).toEqual(1);
    expect(
      fixture.debugElement.queryAll(By.css('a'))[0].nativeElement.text
    ).toEqual('Home');
  });

  it('should display top categories if displayOptions is true', () => {
    component.displayOptions = true;
    fixture.detectChanges();
    expect(fixture.debugElement.queryAll(By.css('li')).length).toEqual(3);
    expect(fixture.debugElement.queryAll(By.css('a')).length).toEqual(3);
    expect(
      fixture.debugElement.queryAll(By.css('a'))[0].nativeElement.text
    ).toEqual('Home');

    expect(
      fixture.debugElement.queryAll(By.css('a'))[1].nativeElement.text
    ).toEqual('Category 1');

    expect(
      fixture.debugElement.queryAll(By.css('a'))[2].nativeElement.text
    ).toEqual('Category 2');
  });

  it('should have route to products page on Home anchor', () => {
    fixture.detectChanges();
    let element = fixture.debugElement.queryAll(By.css('a'))[0].nativeElement;
    expect(element.getAttribute('routerLink')).toEqual('/home/products');
  });

  it('should call onCategoryClick method when a category is clicked', () => {
    const onCategoryClickSpy: jasmine.Spy = spyOn(component, 'onCategoryClick');
    component.displayOptions = true;
    fixture.detectChanges();
    let element = fixture.debugElement.queryAll(By.css('a'))[1].nativeElement;
    element.click();
    expect(onCategoryClickSpy).toHaveBeenCalled();
  });
});
