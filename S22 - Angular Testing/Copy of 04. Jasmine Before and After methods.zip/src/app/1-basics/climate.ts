export function getClimate(fahrenheit: number): string {
  if (fahrenheit < 41) {
    return 'Freezing Cold';
  } else if (fahrenheit < 50) {
    return 'Very Cold';
  } else if (fahrenheit < 65) {
    return 'Cold';
  } else if (fahrenheit < 82) {
    return 'Moderate';
  } else if (fahrenheit < 95) {
    return 'Hot';
  } else if (fahrenheit < 104) {
    return 'Very Hot';
  } else {
    return 'Extremely Hot';
  }
}