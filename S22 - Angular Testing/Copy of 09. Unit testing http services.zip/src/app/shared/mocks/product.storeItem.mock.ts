export class ProductStoreItemMock {
  loadProducts: any;
  products$: any;
  products: any[] = [];
}
