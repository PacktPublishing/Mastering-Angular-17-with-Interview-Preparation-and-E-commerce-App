export class CartStoreItemMock {
  cart$: any;
  cart: any;
  addProduct(): any {}
  decreaseProductQuantity: any;
  removeProduct: any;
  saveCart: any;
  clearCart: any;
}
