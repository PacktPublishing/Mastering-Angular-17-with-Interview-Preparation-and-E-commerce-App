export class CategoriesStoreItemMock {
  loadCategories(): any {}
  categories$: any;
  topLevelCategories$: any;
}
